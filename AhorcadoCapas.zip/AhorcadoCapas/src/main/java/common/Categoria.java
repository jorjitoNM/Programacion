package common;

public enum Categoria {
    basketball,dessert,movie,yodaquotes;
}
