package Ajedrez;

public class Out {

}
