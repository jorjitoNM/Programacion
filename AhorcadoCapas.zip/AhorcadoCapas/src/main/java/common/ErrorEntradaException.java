package common;

public class ErrorEntradaException extends Exception{

}
