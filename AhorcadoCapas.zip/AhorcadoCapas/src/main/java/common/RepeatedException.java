package common;

public class RepeatedException extends  Exception{

}
