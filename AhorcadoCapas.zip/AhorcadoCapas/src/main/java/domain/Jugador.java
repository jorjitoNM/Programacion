package domain;

public class Jugador {
    private String nombre;
    public Jugador () {
        nombre = "jugador";
    }
    public Jugador (String nombre) {
        this.nombre = nombre;
    }
}
