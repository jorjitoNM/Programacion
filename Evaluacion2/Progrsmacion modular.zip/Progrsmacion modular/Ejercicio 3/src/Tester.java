public class Tester {
    public static void main(String[] args) {
        int[] numeros = new int[10];
        System.out.println("Cargamos el array el Array");
        numeros. = OperacionesArray.array();
        OperacionesArray.array();
        System.out.println("Mostramos el Array");
        System.out.println(OperacionesArray.array());
        System.out.println("Ordenamos el Array y lo mostramos");
        System.out.println(OperacionesArray.ordenado(numeros));

    }
}